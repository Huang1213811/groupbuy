package cn.stylefeng.guns.modular.pateint_health_manager.service;

import cn.stylefeng.guns.modular.system.model.PatientHealth;
import com.baomidou.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author zxx
 * @since 2018-12-29
 */
public interface IPatientHealthService extends IService<PatientHealth> {

}
