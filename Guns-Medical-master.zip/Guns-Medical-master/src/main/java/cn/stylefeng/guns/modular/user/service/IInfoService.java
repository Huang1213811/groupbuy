package cn.stylefeng.guns.modular.user.service;

import cn.stylefeng.guns.modular.system.model.Info;
import com.baomidou.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author zxx
 * @since 2018-12-29
 */
public interface IInfoService extends IService<Info> {

}
